local t =
	Def.ActorFrame {
	LoadActor("lift") .. {}
}
return t
