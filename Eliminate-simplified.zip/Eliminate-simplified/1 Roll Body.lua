return Def.Sprite {
	Texture="Rolls/Roll Body";
	Frame0000=0;
	Delay0000=1;
};