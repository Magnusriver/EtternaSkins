local noteType = "bar"

return Def.Sprite {
	Texture="Notes/" .. noteType .. "/_Blue Hold TopCap";
	Frame0000=0;
	Delay0000=1;
};