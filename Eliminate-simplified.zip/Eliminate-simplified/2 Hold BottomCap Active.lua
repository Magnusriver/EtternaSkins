local noteType = "bar"

return Def.Sprite {
	Texture="Notes/" .. noteType .. "/_Blue Hold BottomCap";
	Frame0000=0;
	Delay0000=1;
};