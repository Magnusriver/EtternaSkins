local Reverse = string.find(GAMESTATE:GetPlayerState(pn):GetPlayerOptionsString("ModsLevel_Preferred"), "Reverse");

--Some positions rely on playerConfig. This check is for compatibility
if playerConfig then
	stagePosOffset = playerConfig:get_data(pn_to_profile_slot(PLAYER_1)).GameplayXYCoordinates["4K"].NotefieldY
else
	stagePosOffset = 0
end

local rawMini = GAMESTATE:GetPlayerState(pn):GetCurrentPlayerOptions():Mini()
--Variable that scales back to 1 according to mini%. Works for both zoom and for some but not all coordinates
--Thanks to ecafree2 for this equation
local miniAdjustedScale = 1/(1-(rawMini/2))


--Set stage borders to on/off depending on metrics
if tostring(NOTESKIN:GetMetric("NoteskinPreferences","StageBorderToggle")) == "off" then
	stageBorderActive = 0
else
	stageBorderActive = 1
end

--Set stage bottom to on/off depending on metrics
if tostring(NOTESKIN:GetMetric("NoteskinPreferences","StageBottomToggle")) == "off" then
	stageBottomActive = 0
else
	stageBottomActive = 1
end

--Set stage buttons to on/off depending on metrics
if tostring(NOTESKIN:GetMetric("NoteskinPreferences","StageButtonToggle")) == "off" then
	stageButtonActive = 0
else
	stageButtonActive = 1
end

--Set health bar to on/off depending on metrics
if tostring(NOTESKIN:GetMetric("NoteskinPreferences","HealthbarToggle")) == "off" then
	healthActive = 0
else
	healthActive = 1
end

--Define health bar positions
local healthbarPosX	= 38
local healthbarPosYDown = -60
local healthbarPosYUp = 260

local t = Def.ActorFrame{

--Notefield laser graphic
	Def.Sprite {
		Texture="Lasers/" .. tostring(NOTESKIN:GetMetric("NoteskinPreferences","LaserToggle"));
		Frame0000=0;
		Delay0000=1;
		InitCommand=function(self)
			if Reverse then
				self:blend("BlendMode_Add")
				self:addy(8)
				self:zoomto(64,32)
				self:valign(1)
				self:diffusealpha(0)
			else
				self:blend("BlendMode_Add")
				self:addy(-8)
				self:zoomto(64,32)
				self:valign(1)
				self:diffusealpha(0)
				self:addrotationz(180)
			end
		end,
		PressCommand=function(self)
			self:stoptweening()
			self:zoomto(64,32)
			self:linear(.032)
			self:diffusealpha(.68)
		end,
		LiftCommand=function(self)
			self:stoptweening()
			self:linear(.15)
			self:zoomto(64,0)
			self:diffusealpha(0)
		end,
		NoneCommand=function(self)
		end
	};

--Stage Right
	Def.Sprite {
				Texture="Stage/right";
				Frame0000=0;
				Delay0000=1;
				--OnCommand instead of InitCommand in order to make the screen check work
				OnCommand=function(self)

					--Fade texture if outside gameplay/practice
					--mainly for song select and player options preview
					if SCREENMAN:GetTopScreen():GetName() == "ScreenGameplay" or SCREENMAN:GetTopScreen():GetName() == "ScreenGameplaySyncMachine" or SCREENMAN:GetTopScreen():GetName() == "ScreenGameplayPractice" then
						--No fade if in gameplay
						stageFade = 0
					else
						--Fade stage outside of gameplay
						--Mainly for song select and player options preview
						stageFade = 0.1
						--Mini is not applied outside gameplay, so let's just make this 1
						miniAdjustedScale = 1
					end


					if Reverse then
						self:halign(0)
						self:zoom(0.44444444 * miniAdjustedScale)
						self:diffusealpha(stageBorderActive)
						self:addx(32)
						self:addy((-163.5 - stagePosOffset) * miniAdjustedScale)
						self:fadebottom(stageFade)
						self:fadetop(stageFade)
					else
						self:halign(0)
						self:zoom(0.44444444 * miniAdjustedScale)
						self:diffusealpha(stageBorderActive)
						self:addx(32)
						self:addy((163.5 + stagePosOffset) * miniAdjustedScale)
						self:fadebottom(stageFade)
						self:fadetop(stageFade)
					end
				end,
			};

--Receptor button idle
	Def.Sprite {
		Texture="Stage/1 button idle";
		Frame0000=0;
		Delay0000=1;
		InitCommand=function(self)
			if Reverse then
				self:zoomto(64,64)
				self:diffusealpha(stageButtonActive)
			else
				self:zoomto(64,64)
				self:diffusealpha(stageButtonActive)
			end
		end,
		PressCommand=function(self)
			self:diffusealpha(stageButtonActive)
		end,
		LiftCommand=function(self)
			self:stoptweening()
		end,
		NoneCommand=function(self)
			self:diffusealpha(stageButtonActive)
		end
	};

--Receptor button pressed
	Def.Sprite {
		Texture="Stage/1 button pressed";
		Frame0000=0;
		Delay0000=1;
		InitCommand=function(self)
			if Reverse then
				self:zoomto(64,64)
				self:diffusealpha(0)
			else
				self:zoomto(64,64)
				self:diffusealpha(0)
			end
		end,
		PressCommand=function(self)
			self:stoptweening()
			self:linear(.016)
			self:diffusealpha(stageButtonActive)
		end,
		LiftCommand=function(self)
			self:stoptweening()
			self:sleep(.032)
			self:linear(.064)
			self:diffusealpha(0)
		end,
		NoneCommand=function(self)
			self:diffusealpha(0)
		end
	};

--Health bar
	Def.Sprite {
			Name="Health chill";
			Texture="Stage/health chill";
			Frame0000=0;
			Delay0000=1;
			OnCommand=function(self)
			local health = STATSMAN:GetCurStageStats():GetPlayerStageStats(pn):GetCurrentLife()

				if SCREENMAN:GetTopScreen():GetName() ~= "ScreenGameplay" and SCREENMAN:GetTopScreen():GetName() ~= "ScreenGameplaySyncMachine" and SCREENMAN:GetTopScreen():GetName() ~= "ScreenGameplayPractice" then
					miniAdjustedScale = 1
				end

				if Reverse then
					self:halign(0)
					self:zoom(.5 * miniAdjustedScale)
					self:diffusealpha(healthActive)
					self:addy((stagePosOffset + healthbarPosYDown) * miniAdjustedScale)
					self:addx(healthbarPosX)
				else
					self:halign(0)
					self:zoom(.5 * miniAdjustedScale)
					self:diffusealpha(healthActive)
					self:addy((stagePosOffset + healthbarPosYUp) * miniAdjustedScale)
					self:addx(healthbarPosX)
				end

				--If there's no crop on init the health bar will jitter on first hit, so croptop() is necessary here
				self:croptop(health)

			end,
			JudgmentMessageCommand=function(self)
			--Smooth cropping based on HP
			--Sectioned so it uses a different texture under 40% health
			local health = STATSMAN:GetCurStageStats():GetPlayerStageStats(pn):GetCurrentLife()
					--croptop(1 - health) effectively reverses the value of the command
					--100% health makes "health" 1, which would make the bar disappear without the reversal
					self:stoptweening()
					self:decelerate(0.128)
					self:diffusealpha(healthActive)
					self:croptop( 1 - health )
			end
		};

--Stage bottom
Def.Sprite {
		Texture="Stage/bottom";
		Frame0000=0;
		Delay0000=1;
		InitCommand=function(self)
			if Reverse then
				self:valign(0)
				self:halign(0)
				self:zoom(0.44444444)
				self:diffusealpha(stageBottomActive)
				self:addy(60 * miniAdjustedScale)
				self:addx(-113)
			else
				--Reversed alignment due to rotation
				self:valign(1)
				self:halign(1)
				self:zoom(0.44444444)
				self:diffusealpha(stageBottomActive)
				--For some reason I need a different y offset for upscroll
				self:addy(-60 * miniAdjustedScale)
				self:addx(-113)
			end
		end,
	};

};

return t;