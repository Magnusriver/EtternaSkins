local noteType = "bar"

return Def.Sprite {
	Texture="Notes/" .. noteType .. "/_White Hold TopCap";
	Frame0000=0;
	Delay0000=1;
};