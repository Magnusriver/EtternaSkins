return Def.Sprite {
	Texture="Rolls/Roll BottomCap";
	Frame0000=0;
	Delay0000=1;
};